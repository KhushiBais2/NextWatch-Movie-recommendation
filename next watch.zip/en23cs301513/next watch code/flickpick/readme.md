# NextWatch – AI Based Movie Recommendation System
 
## Project Description
NextWatch is a web-based movie recommendation system developed using Flask, HTML, CSS, and JavaScript. The system recommends movies using content-based filtering techniques with TF-IDF vectorization and cosine similarity. It allows users to browse movies, search films, get personalized recommendations, filter movies by mood and genre, and manage a watchlist.
It is  Movie Recommendation System that leverages Collaborative Filtering, Content-Based Filtering, and a Hybrid approach to deliver accurate and personalised movie recommendations. The system incorporates user rating history, movie data, and semantic similarity to generate meaningful suggestions.

The application supports both Hollywood and Bollywood movies and provides an interactive and responsive user interface.

#Technology Stack
Layer	Technology / Tool	
Frontend	:HTML, CSS, JavaScript	
Backend:	Flask (Python)
Recommendation  Engine	:scikit-learn	
Feature Processing:	TF-IDF Vectorizer	
Similarity Measure:	Cosine Similarity	
Data Storage	:JSON (movies.json)	
Session Management	:Flask Session	
External API	:TMDB API	
Development Tools	:VS Code, Python	

##Features Included
1)Movie recommendation using TF-IDF and cosine similarity
2)Mood-based movie recommendation
3)Browse Hollywood and Bollywood movies
4)Dynamic movie search functionality
5)Filter movies by genre, rating, year, and language
6)Watchlist management using Flask session
7)Responsive frontend interface
8)Movie poster integration using external APIs for fetching movie posters and improving the visual representation of movie results

#Installation /step to run the project
The following steps describe how to install and run the NextWatch Movie Recommendation System on a development machine   
Step 1 – Clone the Repository 
 Git clone https://github.com//nextwatch-movie-recommendation.git 
 cd nextwatch-movie-recommendation
Step 2 – Create Virtual Environment  
python -m venv venv
 venv\Scripts\activate (Windows)  
# OR 
source venv/bin/activate (Mac/Linux) 
Step 3 – Install Dependencies 
pip install flask scikit-learn numpy pandas requests   

Step 4 – Configure Environment 
Create a .env file 
and
add:  FLASK_APP=app.py  
FLASK_ENV=development  
Step 5: – Open in Browser 
 Open your browser 
and 
go to:  http://localhost:5000  

##Project Structure
NextWatch/
├── app.py                  ← Flask backend (all API routes)
├── requirements.txt        ← Python dependencies
│
├── data/
│   └── movies_db.py        ← Master movie database (50+ movies)
│
├── ml/
│   └── recommender.py      ← TF-IDF + Cosine Similarity ML engine
│
├── templates/
│   ├── index.html          ← Main discover page
│   ├── bollywood.html      ← Bollywood dedicated page
│   └── watchlist.html      ← My Watchlist page
│
└── static/
    ├── css/
    │   └── main.css        ← Full design system (dark cinematic theme)
    └── js/
        └── app.js          ← Frontend logic (API calls, filters, modal, etc.)
